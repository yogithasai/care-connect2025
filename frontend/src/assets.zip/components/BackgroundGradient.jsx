export default function BackgroundGradient() {
  return (
    <div className="fixed inset-0 -z-10 bg-gradient-to-br from-blue-50 via-white to-emerald-50" aria-hidden="true"></div>
  );
}


