import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import AnimatedPage from "../components/AnimatedPage";
import BackgroundGradient from "../components/BackgroundGradient";
import Container from "../components/Container";

export default function Home() {
  return (
    <>
      <Navbar />
      <BackgroundGradient />
      <AnimatedPage>
        <Container>
          <div className="text-center mt-20 mb-16">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Welcome to CareConnect</h1>
            <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">Your AI-powered healthcare assistant.</p>
            <div className="mt-8">
              <a href="/login" className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:shadow-md transition">Get Started</a>
            </div>
          </div>
        </Container>
      </AnimatedPage>
      <Footer />
    </>
  );
}
